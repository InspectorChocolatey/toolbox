﻿

/**
 * 
 *  https://stackoverflow.com/questions/17193825/loading-picturebox-image-from-resource-file-with-path-part-3 
 *  https://stackoverflow.com/questions/15564944/remove-the-last-three-characters-from-a-string
 * 
 * 
 * 
 * 
 * 
 */
namespace AokUserInterface
{
    using System;
    using System.IO;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;
    using AokUserInterface.AoKCommons;

    public partial class HomeForm : Form
    {
        public string LocationPath { get; set; }
        public string ImageLogoPath { get; set; }

        public HomeForm()
        {
            InitializeComponent();
            LocationPath = GetType().Assembly.Location;
            ImageLogoPath = LocationPath.Substring(0, LocationPath.Length - 30) + @"Img\aok.png";

            //MessageBox.Show(this.ImageLogoPath);

            if (File.Exists(ImageLogoPath))
            {
                //MessageBox.Show("Filepath found: " + this.LocationPath);
                PictureBox1.Image = Image.FromFile(ImageLogoPath);
                PictureBox1.Height = PictureBox1.Height * 2;
            }
            else
            {
                MessageBox.Show("Filepath NOT found: " + LocationPath);
                Application.Exit();
            }
            
        }

        private void ExitApplication(object sender, EventArgs e)
        {
            Close();
        }

        private void CreateVillager(object sender, EventArgs e)
        {

        }

        public void SleepForSpecifiedAmmount()
        {
            Thread.Sleep(Convert.ToInt32(TextBoxDelaySeconds.Text) * 1000 );
        }

        private void CreateVillagerButtonClicked(object sender, EventArgs e)
        {
            SleepForSpecifiedAmmount();

            using (TownCenter townCenter = new TownCenter())
            {
                townCenter.QueCreateVillager();
                SleepForSpecifiedAmmount();
                townCenter.SetGatherPoint();
                SleepForSpecifiedAmmount();

                using (GameAction gameAction = new GameAction())
                {
                    gameAction.ExitMainAoEWindowContainer();
                }
            }
        }

        public void SleepForOneSecond()
        {
            Thread.Sleep(1000);
        }

        private void ButtonCreateHouseClicked(object sender, EventArgs e)
        {
            SleepForSpecifiedAmmount();

            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            SleepForOneSecond();
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_A);
            SleepForOneSecond();
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_Q);

            SleepForSpecifiedAmmount();

            using (GameAction gameAction = new GameAction())
            {
                gameAction.ExitMainAoEWindowContainer();
            }
        }
    }
}
