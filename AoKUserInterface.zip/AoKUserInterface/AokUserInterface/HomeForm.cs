﻿

/**
 * 
 *  https://stackoverflow.com/questions/17193825/loading-picturebox-image-from-resource-file-with-path-part-3 
 *  https://stackoverflow.com/questions/15564944/remove-the-last-three-characters-from-a-string
 *  https://stackoverflow.com/questions/463299/how-do-i-make-a-textbox-that-only-accepts-numbers
 * 
 * 
 * 
 * 
 */
namespace AokUserInterface
{
    using System;
    using System.IO;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;
    using AokUserInterface.AoKCommons;

    public partial class HomeForm : Form
    {
        public string LocationPath { get; set; }
        public string ImageLogoPath { get; set; }

        public HomeForm()
        {
            InitializeComponent();
            LocationPath = GetType().Assembly.Location;
            ImageLogoPath = LocationPath.Substring(0, LocationPath.Length - 30) + @"Img\aok.png";

            if (File.Exists(ImageLogoPath))
            {
                PictureBox1.Image = Image.FromFile(ImageLogoPath);
                PictureBox1.Height = PictureBox1.Height * 2;
            }
            else
            {
                MessageBox.Show("Filepath NOT found: " + LocationPath);
                Application.Exit();
            }

        }

        private void ExitApplication(object sender, EventArgs e)
        {
            Close();
        }

        private void CreateVillager(object sender, EventArgs e)
        {

        }

        public bool InputIsSufficient()
        {
            return string.IsNullOrEmpty(this.TextBoxDelaySeconds.Text) ? false : true;
        }

        public void SleepForSpecifiedAmmount()
        {
            Thread.Sleep(Convert.ToInt32(TextBoxDelaySeconds.Text) * 1000);
        }

        private void CreateVillagerButtonClicked(object sender, EventArgs e)
        {
            SleepForSpecifiedAmmount();

            using (TownCenter townCenter = new TownCenter())
            {
                townCenter.QueCreateVillager();
                SleepForSpecifiedAmmount();
                townCenter.SetGatherPoint();
                SleepForSpecifiedAmmount();

                using (GameAction gameAction = new GameAction())
                {
                    gameAction.ExitMainAoEWindowContainer();
                }
            }
        }

        public void SleepForOneSecond()
        {
            Thread.Sleep(1000);
        }

        private void ButtonCreateHouseClicked(object sender, EventArgs e)
        {
            SleepForSpecifiedAmmount();

            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            SleepForOneSecond();
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_A);
            SleepForOneSecond();
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_Q);
            UserPrompt.ReadText("How down control and make two houses");
            SleepForSpecifiedAmmount();

            using (GameAction gameAction = new GameAction())
            {
                gameAction.ExitMainAoEWindowContainer();
            }
        }

        private void ButtonOpenChatFormClicked(object sender, EventArgs e)
        {
            if (this.InputIsSufficient())
            {
                SleepForSpecifiedAmmount();

                using (GameAction gameAction = new GameAction())
                {
                    gameAction.OpenChatBox();

                }
                ChatForm chatForm = new ChatForm();
                chatForm.Show();
            }
            else
            {
                MessageBox.Show("Missing Parameter: Sleep Time");
            }
        }

        private void ButtonOpenResourceFormClicked(object sender, EventArgs e)
        {
            ResourcesForm resourcesForm = new ResourcesForm();
            resourcesForm.Show();
        }

        private void HandleInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
