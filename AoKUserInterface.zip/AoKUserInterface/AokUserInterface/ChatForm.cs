﻿namespace AokUserInterface
{
    using System;
    using System.Windows.Forms;

    public partial class ChatForm : Form
    {
        public ChatForm()
        {
            InitializeComponent();
        }

        private void ButtonCloseClicked(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
