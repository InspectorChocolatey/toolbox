﻿namespace AokUserInterface
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelMain = new System.Windows.Forms.Panel();
            this.PanelLeft = new System.Windows.Forms.Panel();
            this.PanelTop = new System.Windows.Forms.Panel();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.TextBoxDelaySeconds = new System.Windows.Forms.TextBox();
            this.LabelDelaySeconds = new System.Windows.Forms.Label();
            this.ButtonCreateVillager = new System.Windows.Forms.Button();
            this.ButtonCreateHouse = new System.Windows.Forms.Button();
            this.PanelMain.SuspendLayout();
            this.PanelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelMain
            // 
            this.PanelMain.BackColor = System.Drawing.Color.Gainsboro;
            this.PanelMain.Controls.Add(this.ButtonCreateHouse);
            this.PanelMain.Controls.Add(this.ButtonCreateVillager);
            this.PanelMain.Controls.Add(this.LabelDelaySeconds);
            this.PanelMain.Controls.Add(this.TextBoxDelaySeconds);
            this.PanelMain.Controls.Add(this.PanelTop);
            this.PanelMain.Controls.Add(this.PanelLeft);
            this.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelMain.Location = new System.Drawing.Point(0, 0);
            this.PanelMain.Name = "PanelMain";
            this.PanelMain.Size = new System.Drawing.Size(800, 450);
            this.PanelMain.TabIndex = 0;
            // 
            // PanelLeft
            // 
            this.PanelLeft.BackColor = System.Drawing.Color.DarkRed;
            this.PanelLeft.Controls.Add(this.ButtonExit);
            this.PanelLeft.Controls.Add(this.PictureBox1);
            this.PanelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelLeft.Location = new System.Drawing.Point(0, 0);
            this.PanelLeft.Name = "PanelLeft";
            this.PanelLeft.Size = new System.Drawing.Size(200, 450);
            this.PanelLeft.TabIndex = 0;
            // 
            // PanelTop
            // 
            this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.PanelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTop.Location = new System.Drawing.Point(200, 0);
            this.PanelTop.Name = "PanelTop";
            this.PanelTop.Size = new System.Drawing.Size(600, 100);
            this.PanelTop.TabIndex = 1;
            // 
            // PictureBox1
            // 
            this.PictureBox1.Location = new System.Drawing.Point(3, 3);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(194, 101);
            this.PictureBox1.TabIndex = 0;
            this.PictureBox1.TabStop = false;
            // 
            // ButtonExit
            // 
            this.ButtonExit.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonExit.Location = new System.Drawing.Point(13, 406);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(172, 32);
            this.ButtonExit.TabIndex = 1;
            this.ButtonExit.Text = "Exit";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ExitApplication);
            // 
            // TextBoxDelaySeconds
            // 
            this.TextBoxDelaySeconds.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxDelaySeconds.Location = new System.Drawing.Point(419, 120);
            this.TextBoxDelaySeconds.Name = "TextBoxDelaySeconds";
            this.TextBoxDelaySeconds.Size = new System.Drawing.Size(163, 30);
            this.TextBoxDelaySeconds.TabIndex = 2;
            // 
            // LabelDelaySeconds
            // 
            this.LabelDelaySeconds.AutoSize = true;
            this.LabelDelaySeconds.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold);
            this.LabelDelaySeconds.Location = new System.Drawing.Point(223, 121);
            this.LabelDelaySeconds.Name = "LabelDelaySeconds";
            this.LabelDelaySeconds.Size = new System.Drawing.Size(190, 25);
            this.LabelDelaySeconds.TabIndex = 3;
            this.LabelDelaySeconds.Text = "Delay Seconds:";
            // 
            // ButtonCreateVillager
            // 
            this.ButtonCreateVillager.BackColor = System.Drawing.Color.RosyBrown;
            this.ButtonCreateVillager.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateVillager.Location = new System.Drawing.Point(228, 281);
            this.ButtonCreateVillager.Name = "ButtonCreateVillager";
            this.ButtonCreateVillager.Size = new System.Drawing.Size(239, 32);
            this.ButtonCreateVillager.TabIndex = 4;
            this.ButtonCreateVillager.Text = "Create Villager";
            this.ButtonCreateVillager.UseVisualStyleBackColor = false;
            this.ButtonCreateVillager.Click += new System.EventHandler(this.CreateVillagerButtonClicked);
            // 
            // ButtonCreateHouse
            // 
            this.ButtonCreateHouse.BackColor = System.Drawing.Color.RosyBrown;
            this.ButtonCreateHouse.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateHouse.Location = new System.Drawing.Point(228, 337);
            this.ButtonCreateHouse.Name = "ButtonCreateHouse";
            this.ButtonCreateHouse.Size = new System.Drawing.Size(239, 32);
            this.ButtonCreateHouse.TabIndex = 5;
            this.ButtonCreateHouse.Text = "Create House";
            this.ButtonCreateHouse.UseVisualStyleBackColor = false;
            this.ButtonCreateHouse.Click += new System.EventHandler(this.ButtonCreateHouseClicked);
            // 
            // HomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PanelMain);
            this.Name = "HomeForm";
            this.Text = "AoKUI : Home ";
            this.PanelMain.ResumeLayout(false);
            this.PanelMain.PerformLayout();
            this.PanelLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelMain;
        private System.Windows.Forms.Panel PanelTop;
        private System.Windows.Forms.Panel PanelLeft;
        private System.Windows.Forms.PictureBox PictureBox1;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Label LabelDelaySeconds;
        private System.Windows.Forms.TextBox TextBoxDelaySeconds;
        private System.Windows.Forms.Button ButtonCreateVillager;
        private System.Windows.Forms.Button ButtonCreateHouse;
    }
}

