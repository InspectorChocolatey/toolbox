﻿namespace AokUserInterface
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelTop = new System.Windows.Forms.Panel();
            this.PanelMain = new System.Windows.Forms.Panel();
            this.ButtonCreateHouse = new System.Windows.Forms.Button();
            this.ButtonCreateVillager = new System.Windows.Forms.Button();
            this.LabelMessage = new System.Windows.Forms.Label();
            this.TextBoxMessages = new System.Windows.Forms.TextBox();
            this.PanelLeft = new System.Windows.Forms.Panel();
            this.ButtonClose = new System.Windows.Forms.Button();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelMain.SuspendLayout();
            this.PanelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelTop
            // 
            this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.PanelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTop.Location = new System.Drawing.Point(200, 0);
            this.PanelTop.Name = "PanelTop";
            this.PanelTop.Size = new System.Drawing.Size(600, 100);
            this.PanelTop.TabIndex = 1;
            // 
            // PanelMain
            // 
            this.PanelMain.BackColor = System.Drawing.Color.Gainsboro;
            this.PanelMain.Controls.Add(this.ButtonCreateHouse);
            this.PanelMain.Controls.Add(this.ButtonCreateVillager);
            this.PanelMain.Controls.Add(this.LabelMessage);
            this.PanelMain.Controls.Add(this.TextBoxMessages);
            this.PanelMain.Controls.Add(this.PanelTop);
            this.PanelMain.Controls.Add(this.PanelLeft);
            this.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelMain.Location = new System.Drawing.Point(0, 0);
            this.PanelMain.Name = "PanelMain";
            this.PanelMain.Size = new System.Drawing.Size(800, 450);
            this.PanelMain.TabIndex = 1;
            // 
            // ButtonCreateHouse
            // 
            this.ButtonCreateHouse.BackColor = System.Drawing.Color.RosyBrown;
            this.ButtonCreateHouse.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateHouse.Location = new System.Drawing.Point(228, 406);
            this.ButtonCreateHouse.Name = "ButtonCreateHouse";
            this.ButtonCreateHouse.Size = new System.Drawing.Size(239, 32);
            this.ButtonCreateHouse.TabIndex = 5;
            this.ButtonCreateHouse.Text = "Create House";
            this.ButtonCreateHouse.UseVisualStyleBackColor = false;
            // 
            // ButtonCreateVillager
            // 
            this.ButtonCreateVillager.BackColor = System.Drawing.Color.RosyBrown;
            this.ButtonCreateVillager.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateVillager.Location = new System.Drawing.Point(228, 368);
            this.ButtonCreateVillager.Name = "ButtonCreateVillager";
            this.ButtonCreateVillager.Size = new System.Drawing.Size(239, 32);
            this.ButtonCreateVillager.TabIndex = 4;
            this.ButtonCreateVillager.Text = "Create Villager";
            this.ButtonCreateVillager.UseVisualStyleBackColor = false;
            // 
            // LabelMessage
            // 
            this.LabelMessage.AutoSize = true;
            this.LabelMessage.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold);
            this.LabelMessage.Location = new System.Drawing.Point(223, 121);
            this.LabelMessage.Name = "LabelMessage";
            this.LabelMessage.Size = new System.Drawing.Size(117, 25);
            this.LabelMessage.TabIndex = 3;
            this.LabelMessage.Text = "Message:";
            // 
            // TextBoxMessages
            // 
            this.TextBoxMessages.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxMessages.Location = new System.Drawing.Point(228, 146);
            this.TextBoxMessages.Multiline = true;
            this.TextBoxMessages.Name = "TextBoxMessages";
            this.TextBoxMessages.Size = new System.Drawing.Size(560, 129);
            this.TextBoxMessages.TabIndex = 2;
            // 
            // PanelLeft
            // 
            this.PanelLeft.BackColor = System.Drawing.Color.DarkRed;
            this.PanelLeft.Controls.Add(this.ButtonClose);
            this.PanelLeft.Controls.Add(this.PictureBox1);
            this.PanelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelLeft.Location = new System.Drawing.Point(0, 0);
            this.PanelLeft.Name = "PanelLeft";
            this.PanelLeft.Size = new System.Drawing.Size(200, 450);
            this.PanelLeft.TabIndex = 0;
            // 
            // ButtonClose
            // 
            this.ButtonClose.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonClose.Location = new System.Drawing.Point(13, 406);
            this.ButtonClose.Name = "ButtonClose";
            this.ButtonClose.Size = new System.Drawing.Size(172, 32);
            this.ButtonClose.TabIndex = 1;
            this.ButtonClose.Text = "Close";
            this.ButtonClose.UseVisualStyleBackColor = true;
            this.ButtonClose.Click += new System.EventHandler(this.ButtonCloseClicked);
            // 
            // PictureBox1
            // 
            this.PictureBox1.Location = new System.Drawing.Point(3, 3);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(194, 101);
            this.PictureBox1.TabIndex = 0;
            this.PictureBox1.TabStop = false;
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PanelMain);
            this.Name = "ChatForm";
            this.Text = "Chat Form";
            this.PanelMain.ResumeLayout(false);
            this.PanelMain.PerformLayout();
            this.PanelLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelTop;
        private System.Windows.Forms.Panel PanelMain;
        private System.Windows.Forms.Button ButtonCreateHouse;
        private System.Windows.Forms.Button ButtonCreateVillager;
        private System.Windows.Forms.Label LabelMessage;
        private System.Windows.Forms.TextBox TextBoxMessages;
        private System.Windows.Forms.Panel PanelLeft;
        private System.Windows.Forms.Button ButtonClose;
        private System.Windows.Forms.PictureBox PictureBox1;
    }
}