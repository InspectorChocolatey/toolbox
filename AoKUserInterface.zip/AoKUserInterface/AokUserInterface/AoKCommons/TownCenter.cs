﻿/**
 * 
 *  https://steamcommunity.com/app/221380/discussions/0/2741975115065683543/
 *  
 * 
 * 
 * 
 * 
 * 
 */

namespace AokUserInterface.AoKCommons
{
    using System;
    using AokUserInterface.AoKCommons;

    public class TownCenter : IDisposable
    {
        public TownCenter()
        {

        }

        public void QueCreateVillager()
        {
            using (HotKeyManager hotKeyManager = new HotKeyManager())
            {
                hotKeyManager.MakeVillager();
            }
        }

        public void SetGatherPoint()
        {
            using (HotKeyManager hotKeyManager = new HotKeyManager())
            {
                hotKeyManager.GoToTownCenter();
                KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_T);
            }
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                }
                disposedValue = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
