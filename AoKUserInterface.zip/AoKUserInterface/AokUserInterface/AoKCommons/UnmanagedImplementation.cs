﻿
/**
 *  https://docs.microsoft.com/en-us/dotnet/api/system.runtime.interopservices.dllimportattribute?view=netframework-4.7.2 
 * 
 * 
 * 
 * 
 * 
 * 
 */

namespace AokUserInterface.AoKCommons
{
    using System;
    using System.Runtime.InteropServices;

    public class UnmanagedImplementation
    {
        // Use DllImport to import the Win32 MessageBox function.
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);

        public UnmanagedImplementation()
        {

        }

        public static void ImplementUnmanagedMessageBox()
        {
            MessageBox(new IntPtr(0), "Hello World!", "Hello Dialog", 0);
        }
    }
}
