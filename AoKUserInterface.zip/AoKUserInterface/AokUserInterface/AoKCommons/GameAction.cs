﻿/**
 * 
 *  https://steamcommunity.com/app/221380/discussions/0/2741975115065683543/
 *  
 * 
 * 
 * 
 * 
 * 
 */
namespace AokUserInterface.AoKCommons
{
    using System;
    using AokUserInterface.AoKCommons;

    public class GameAction : IDisposable
    {
        public GameAction()
        {

        }

        public void ExitMainAoEWindowContainer()
        {
            //KeyboardManager.PressKey(KeyboardManager.VK_SHIFT);
            KeyboardManager.PressKey(KeyboardManager.VK_CONTROL);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_ESCAPE);
            //KeyboardManager.ReleaseKey(KeyboardManager.VK_SHIFT);
            KeyboardManager.ReleaseKey(KeyboardManager.VK_CONTROL);
        }

        public void OpenChatBox()
        {
            UserPrompt.ReadText("Opening Chat Window");
            KeyboardManager.PressKey(KeyboardManager.VK_ALT);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_T);
            KeyboardManager.ReleaseKey(KeyboardManager.VK_CONTROL);

        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                }
                disposedValue = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}