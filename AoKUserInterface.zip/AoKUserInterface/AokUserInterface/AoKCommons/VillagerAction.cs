﻿/**
 * 
 *  https://steamcommunity.com/app/221380/discussions/0/2741975115065683543/
 *  
 * 
 * 
 * 
 * 
 * 
 */
namespace AokUserInterface.AoKCommons
{
    using System;
    using System.Threading;
    using AokUserInterface.AoKCommons;

    public class VillagerAction : IDisposable
    {
        public VillagerAction()
        {

        }

        public void BuildLumberCamp()
        {
            Thread.Sleep(5000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_A);
            Thread.Sleep(1000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_R);

            Thread.Sleep(1000);
        }

        public void BuildMiningCamp()
        {

        }

        public void BuildCastle()
        {

        }


        public void BuildHouse()
        {
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_A);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_Q);
        }

        public void BuildHouses(int count)
        {

        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                }
                disposedValue = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
