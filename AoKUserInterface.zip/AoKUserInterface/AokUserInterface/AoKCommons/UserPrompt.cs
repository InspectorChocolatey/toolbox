﻿namespace AokUserInterface.AoKCommons
{
    using System.Speech.Synthesis;  /*  _SpeechSynthesizer */

    public class UserPrompt
    {
        public UserPrompt()
        {

        }

        public static void ReadText(string text)
        {
            using (SpeechSynthesizer ss = new SpeechSynthesizer())
            {
                ss.Speak(text);
            }
        }

        public static void ReadTextAsync(string text)
        {
            using (SpeechSynthesizer ss = new SpeechSynthesizer())
            {
                ss.SpeakAsync(text);
            }
        }
    }
}
