﻿namespace AokUserInterface.AoKCommons
{
    using System;
    using System.Threading;
    using AokUserInterface.AoKCommons;

    public class HotKeyManager : IDisposable
    {
        public HotKeyManager()
        {

        }

        public void StartOfGameRoutine()
        {
            using (VillagerAction villagerAction = new VillagerAction())
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("Assign Task to: villager {0}", i);
                    Console.Beep();
                    KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
                    Thread.Sleep(2000);
                    if (i == 1)
                    {
                        villagerAction.BuildLumberCamp();
                    }
                }
            }

            /*
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            Thread.Sleep(2000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            Thread.Sleep(2000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            Thread.Sleep(2000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_OEM_PERIOD);
            Thread.Sleep(2000);
            */
        }


        //public void 

        public void GoToTownCenter()
        {
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_H);
        }

        public void MakeVillager()
        {
            GoToTownCenter();
            Thread.Sleep(2000);
            KeyboardManager.PressAndReleaseKey(KeyboardManager.VK_A);
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                }
                disposedValue = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
