﻿/**
 *  https://ageofempires.fandom.com/wiki/Dark_Age
 *  https://ageofempires.fandom.com/wiki/Feudal_Age
 * 
 * 
 * 
 * 
 * 
 */

namespace AokUserInterface.AoKCommons
{
    using System;   /*  _.IDisposable   */

    public class Age : IDisposable
    {
        public int CurrentAge = 0;

        public Age()
        {

        }

        public void QueUpgrade()
        {
            this.CurrentAge = this.CurrentAge + 1;
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                }
                disposedValue = true;
            }
        }

        void IDisposable.Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
