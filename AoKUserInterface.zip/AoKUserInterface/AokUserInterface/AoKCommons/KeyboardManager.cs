﻿/**
 * 
 *  https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes
 *  BE
 * 
 * 
 * 
 * 
 * 
 */
namespace AokUserInterface.AoKCommons
{
    using System.Runtime.InteropServices; /* _.DllImportAttribute */

    public class KeyboardManager
    {
        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo);

        public KeyboardManager()
        {

        }

        public const int VK_ALT = 0x12;
        public const int VK_CONTROL = 0x11;
        public const int VK_ESCAPE = 0x1B;
        public const int VK_OEM_PERIOD = 0xBE; // .   BE

        public const int VK_LBUTTON = 0x01; // Left click
        public const int VK_RBUTTON = 0x02; // Right click
        public const int VK_TAB = 0x09;     // TAB
        public const int VK_SHIFT = 0x10;   // SHIFT
        public const int VK_CAPITAL = 0x14; // CAPS LOCK
        public const int VK_DELETE = 0x2E;  // DELETE
        public const int VK_ZERO = 0x30;    // 0
        public const int VK_ONE = 0x31;     // 1
        public const int VK_TWO = 0x32;     // 2
        public const int VK_THREE = 0x33;   // 3
        public const int VK_FOUR = 0x34;    // 4
        public const int VK_FIVE = 0x35;    // 5
        public const int VK_SIX = 0x36;     // 6
        public const int VK_SEVEN = 0x37;   // 7
        public const int VK_EIGHT = 0x38;   // 8
        public const int VK_NINE = 0x39;    // 9
        public const int VK_NUMPAD0 = 0x60; // 0
        public const int VK_NUMPAD1 = 0x61; // 1
        public const int VK_NUMPAD2 = 0x62; // 2
        public const int VK_NUMPAD3 = 0x63; // 3
        public const int VK_NUMPAD4 = 0x64; // 4
        public const int VK_NUMPAD5 = 0x65; // 5
        public const int VK_NUMPAD6 = 0x66; // 6
        public const int VK_NUMPAD7 = 0x67; // 7
        public const int VK_NUMPAD8 = 0x68; // 8
        public const int VK_NUMPAD9 = 0x69; // 9
        public const int VK_F1 = 0x70; // 1
        public const int VK_F2 = 0x71; // 2
        public const int VK_F3 = 0x72; // 3
        public const int VK_F4 = 0x73; // 4
        public const int VK_F5 = 0x74; // 5
        public const int VK_F6 = 0x75; // 6
        public const int VK_F7 = 0x76; // 7
        public const int VK_F8 = 0x77; // 8
        public const int VK_F9 = 0x78; // 9
        public const int VK_LWIN = 0x5B;    // Left Windows Key
        public const int VK_RETURN = 0x0D;  // Enter
        public const int VK_SPACE = 0x20;   // Space
        public const int VK_A = 0x41; // A key
        public const int VK_B = 0x42; // B key
        public const int VK_C = 0x43; // C key
        public const int VK_D = 0x44; // D key
        public const int VK_E = 0x45; // E key
        public const int VK_F = 0x46; // F key
        public const int VK_G = 0x47; // G key
        public const int VK_H = 0x48; // H key
        public const int VK_I = 0x49; // I key
        public const int VK_J = 0x4A; // J key
        public const int VK_K = 0x4B; // K key
        public const int VK_L = 0x4C; // L key
        public const int VK_M = 0x4D; // M key
        public const int VK_N = 0x4E; // N key
        public const int VK_O = 0x4F; // O key
        public const int VK_P = 0x50; // P key
        public const int VK_Q = 0x51; // Q key
        public const int VK_R = 0x52; // R key
        public const int VK_S = 0x53; // S key
        public const int VK_T = 0x54; // T key
        public const int VK_U = 0x55; // U key
        public const int VK_V = 0x56; // V key
        public const int VK_W = 0x57; // W key
        public const int VK_X = 0x58; // X key
        public const int VK_Y = 0x59; // Y key
        public const int VK_Z = 0x5A; // Z key
        public const int VK_UP = 0x26; // up key
        public const int VK_DOWN = 0x28; // down key
        public const int VK_LEFT = 0x25; // left key
        public const int VK_RIGHT = 0x27; // right key
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const uint KEYEVENTF_EXTENDEDKEY = 0x0001;

        public static void SayWhoIsAweSome()
        {
            for (int i = 0; i < 200; i++)
            {
                PressAndReleaseKey(VK_A);
                PressAndReleaseKey(VK_N);
                PressAndReleaseKey(VK_D);
                PressAndReleaseKey(VK_R);
                PressAndReleaseKey(VK_E);
                PressAndReleaseKey(VK_W);

                PressAndReleaseKey(VK_SPACE);

                PressAndReleaseKey(VK_R);
                PressAndReleaseKey(VK_E);
                PressAndReleaseKey(VK_I);
                PressAndReleaseKey(VK_D);

                PressAndReleaseKey(VK_SPACE);

                PressAndReleaseKey(VK_I);
                PressAndReleaseKey(VK_S);

                PressAndReleaseKey(VK_SPACE);

                PressAndReleaseKey(VK_A);
                PressAndReleaseKey(VK_W);
                PressAndReleaseKey(VK_E);
                PressAndReleaseKey(VK_S);
                PressAndReleaseKey(VK_O);
                PressAndReleaseKey(VK_M);
                PressAndReleaseKey(VK_E);

                PressAndReleaseKey(VK_RETURN);
            }
        }

        public static void PressAndReleaseKey(int key)
        {
            PressKey(key);
            ReleaseKey(key);
        }


        public static void PressKey(int key)
        {
            keybd_event((byte)key, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
        }


        public static void ReleaseKey(int key)
        {
            keybd_event((byte)key, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
        }
    }
}
