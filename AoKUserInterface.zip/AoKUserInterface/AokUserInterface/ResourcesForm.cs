﻿namespace AokUserInterface
{
    using System.IO;
    using System.Drawing;
    using System.Windows.Forms;

    public partial class ResourcesForm : Form
    {
        public string LocationPath { get; set; }
        public string ImageLogoPath { get; set; }

        public ResourcesForm()
        {
            InitializeComponent();
            SetPicture();
        }

        public void SetPicture()
        {
            LocationPath = GetType().Assembly.Location;
            ImageLogoPath = LocationPath.Substring(0, LocationPath.Length - 30) + @"Img\aok.png";

            if (File.Exists(ImageLogoPath))
            {
                PictureBox1.Image = Image.FromFile(ImageLogoPath);
                PictureBox1.Height = PictureBox1.Height * 2;
            }
            else
            {
                MessageBox.Show("Filepath NOT found: " + LocationPath);
                Application.Exit();
            }
        }

        private void ButtonCloseClicked(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
